=== iZ Product Feed ===
Version: 2.0.0
Contributors: Mike Koopman
Tags: Woocommerce Product Feed
Requires at least: Wordpress 4.7.5 + Woocommerce 3.0.8
Tested up to: Wordpress 4.8 + Woocommerce 3.1.0
Stable tag: 4.7.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Product Feed, hardcoded for iZ Sock franchise

== Description ==

Product Feed, hardcoded for iZ Sock franchise. Version 1.0 only supports XML feed for Google Merchant. 
JSON implemented for Clerk.io

== Installation ==

This section describes how to install the plugin and get it working.


1. Upload `iz-rpoduct-feed` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

or

1. Download the zip file
2. Go to Wordpress -> Plugins -> Install plugin -> upload file
3. Select the zip file
4. Activate


== Changelog ==

Version 2.0.0:
- Added JSON feed for Clerk.io
- Fixed minor problems on admin side
